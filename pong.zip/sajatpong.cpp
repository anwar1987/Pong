#include "raylib.h"

int main(void)
{
    const int screenWidth = 800;
    const int screenHeight = 450;
    float ballRadius = 10;
    InitWindow(screenWidth, screenHeight, "Pong-2");
    Vector2 leftpaddelPostion = {10,GetScreenHeight()/2-50};
    Vector2 rightpaddelPostion = {GetScreenWidth()-20,GetScreenHeight()/2-50};
    Vector2 rightpaddelSpeed = {0.0f,0.0f};
    Vector2 ballPosition = { 400, 225 };
    Vector2 ballSpeed = { 5.0f, 4.0f };
    Vector2 rightpaddelSize = { 10, 100 };
    Rectangle rightpaddelbody = {rightpaddelPostion.x,rightpaddelPostion.y,10, 100};

    SetTargetFPS(60);
while (!WindowShouldClose()){
        // Update
        //----------------------------------------------------------------------------------
        ballPosition.x += ballSpeed.x*1;
        ballPosition.y += ballSpeed.y*1;
        //----------------------------------------------------------------------------------
//
    if(ballPosition.y > GetScreenHeight() || ballPosition.y < ballRadius)
    {
        ballSpeed.y *= -1.0f;
    }
    if(IsKeyDown(KEY_W))
    {
        leftpaddelPostion.y -= 8.0f;
    }
        if(IsKeyDown(KEY_S))
    {
        leftpaddelPostion.y += 8.0f;
    }
        if(IsKeyDown(KEY_DOWN))
    {
        rightpaddelPostion.y += 8.0f;
    }
        if(IsKeyDown(KEY_UP))
    {
        rightpaddelPostion.y -= 8.0f;
    }
        //Collision
        if(CheckCollisionCircleRec(ballPosition, ballRadius, rightpaddelbody ))
    {
            ballSpeed.x *= -1.0f;
    }
        // Draw
        BeginDrawing();
            DrawRectangle(rightpaddelPostion.x,rightpaddelPostion.y,10,100,RED);
            DrawRectangle(leftpaddelPostion.x,leftpaddelPostion.y,10,100,RED);
            ClearBackground(RAYWHITE);
            DrawCircleV(ballPosition,  ballRadius , BLACK);
        EndDrawing();
        //----------------------------------------------------------------------------------
    }

    // De-Initialization
    //--------------------------------------------------------------------------------------
    CloseWindow();        // Close window and OpenGL context
    //--------------------------------------------------------------------------------------
    return 0;
    }

