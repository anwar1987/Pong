#include "raylib.h"

int main(void)
{
    // Initialization
    //--------------------------------------------------------------------------------------
    const int screenWidth = 800;
    const int screenHeight = 450;
    SetWindowState(FLAG_VSYNC_HINT);
    InitWindow(screenWidth, screenHeight, "raylib [core] example - keyboard input");
    Vector2 ballPosition = { 50,GetScreenHeight()/2 };
    Rectangle rect={GetScreenWidth()/2+100,GetScreenHeight()/2-150,50,250};
    Vector2 ballSpeed ={10,0};
              // Set our game to run at 60 frames-per-second
    //--------------------------------------------------------------------------------------

    // Main game loop
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {

        ballPosition.x += ballSpeed.x*1;
        if(CheckCollisionCircleRec(ballPosition,  50, rect))
        {
            ballSpeed.x *=-1;
        }
        // Draw     CheckCollisionCircleRec(ballPosition,  50, rect)
        //----------------------------------------------------------------------------------
        BeginDrawing();

            ClearBackground(RAYWHITE);
            DrawText("Collision between rectengel and circle", 10, 10, 20, DARKGRAY);
            DrawRectangleRec(rect, YELLOW);
            DrawCircleV(ballPosition, 50, MAROON);

        EndDrawing();
        //----------------------------------------------------------------------------------
    }

    // De-Initialization
    //--------------------------------------------------------------------------------------
    CloseWindow();        // Close window and OpenGL context
    //--------------------------------------------------------------------------------------

    return 0;
}
