#include "raylib.h"
int main()
{
    const int screenWidth = 800;
    const int screenHeight = 800;
    float ballRadius = 10;
    InitWindow(screenWidth, screenHeight, "PONG-3");
    Vector2 ballPosition = {GetScreenWidth()/2,GetScreenHeight()/2};
    Rectangle rightpaddel ={GetScreenWidth()- 20,GetScreenHeight()/2-50,10, 100};
    Rectangle leftpaddel ={10,GetScreenHeight()/2-50,10, 100};
    Vector2 ballSpeed = {400.0f,200.0f};
    SetTargetFPS(60);

    while (!WindowShouldClose())
    {

    ballPosition.x += ballSpeed.x*GetFrameTime();
    ballPosition.y += ballSpeed.y*GetFrameTime();
    if(ballPosition.y > GetScreenHeight() || ballPosition.y < ballRadius)
    {
        ballSpeed.y *= -1.0f;
    }

    if(CheckCollisionCircleRec(ballPosition,  ballRadius, leftpaddel))
        {
            ballSpeed.x *=-1;
        }
    if(CheckCollisionCircleRec(ballPosition,  ballRadius, rightpaddel))
        {
            ballSpeed.x *=-1;
        }
    if(IsKeyDown(KEY_W))
    {
        leftpaddel.y -= 8.0f;
    }
        if(IsKeyDown(KEY_S))
    {
        leftpaddel.y += 8.0f;
    }
        if(IsKeyDown(KEY_DOWN))
    {
        rightpaddel.y += 8.0f;
    }
        if(IsKeyDown(KEY_UP))
    {
        rightpaddel.y -= 8.0f;
    }

        BeginDrawing();
            DrawRectangleRec(rightpaddel,RED);
            DrawRectangleRec(leftpaddel,RED);
            ClearBackground(RAYWHITE);
            DrawCircleV(ballPosition,  ballRadius , BLACK);
        EndDrawing();
    }
    return 0;
}
